var express = require('express');
var router = express.Router();
var mongoose = require( 'mongoose' );
var User = mongoose.model('User');

	router.route('/login').post(function(req, res){
		var user_data = req.body;
		var res_json = {state: 'failure', user: '', message: ''};
		return res.send({state: 'success', user: {username : user_data.username}}); 
	});

	router.route('/register').post(function(req, res){
		var user_data = req.body;
		var res_json = {state: 'failure', user: '', message: ''};
		return res.send({state: 'success', user: {username : user_data.username}});
	});

	router.route('/logout').post(function(req, res) {
		
	});

	var createHash = function(password){
		return password;
	};

module.exports = router;
